# Fill in information from Blynk Device Info here.
BLYNK_TEMPLATE_ID   = "TMPL6Z6-kF2uu"
BLYNK_TEMPLATE_NAME = "pico"
BLYNK_AUTH_TOKEN    = "67ABQDS-CZnJUlGErQ0izfe9DkSwml93"

# Change the default Blynk server. Applicable for users with a white label plan.
BLYNK_MQTT_BROKER   = "blynk.cloud"